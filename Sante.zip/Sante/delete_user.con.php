<?php
require('modify_user.mod.php');

$req = read_data($bdd);

require('delete_user.view.php');


if (isset($_GET['social_security']))
{
	delete_user($_GET['social_security'], $bdd);
 	?>
		<script>
			alert("Le compte a été supprimé."); 
			window.location.href = "delete_user.con.php";
		</script>
	<?php
}
