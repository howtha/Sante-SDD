<?php
require('modify_user.mod.php');

$req = read_data($bdd);

require('delete_user.view.php');


if (isset($_GET['id']))
{
	delete_user($_GET['id'], $bdd);
 	?>
		<script>
			alert("Le compte a été supprimé."); 
			window.location.href = "delete_user.con.php";
		</script>
	<?php
}
