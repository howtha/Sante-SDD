<?php
require('delete_patient.view.php');


if (isset($_GET['social_security']))
{
  delete_patient($_GET['social_security'], $bdd);
  ?>
    <script>
      alert("Le patient a été supprimé."); 
      window.location.href = "delete_patient.con.php";
    </script>
  <?php
}
