<?php
require('sql.php');
require_once 'googleLib/GoogleAuthenticator.php';
$ga = new GoogleAuthenticator();
$secret = $ga->createSecret();

function info_exist($login, $bdd)
{
	$req = $bdd->prepare('SELECT count(*) FROM users WHERE login = :login');
	$req->execute(array("login"=>$login));

	if ($req->fetch()[0] == 1)
	{
		return true;
	}

	else
	{
		return false;
	}
}

function add_user($social_security, $status, $last_name, $first_name, $birth_date, $email, $login, $password, $secret, $bdd)
{
	if (!info_exist($login, $bdd))
	{
		$req = $bdd->prepare('INSERT INTO users(social_security, status, first_name, last_name, birth_date, email, login, password, google_auth_code) VALUES(:social_security, :status, :first_name, :last_name, :birth_date, :email, :login, :password, :secret)');
		$req->execute(array("social_security"=>$social_security, "status"=>$status, "first_name"=>$first_name, "last_name"=>$last_name, "birth_date"=>$birth_date, "email"=>$email, "login"=>$login, "password"=>sha1($password), "secret"=>$secret));
		return true;
	}

	else
	{
		return false;
	}
}

function view_user($login, $bdd)
{
	if (info_exist($login, $bdd))
	{
		$req = $bdd->prepare('SELECT social_security, first_name, last_name, birth_date, email, login, status, google_auth_code FROM users WHERE login = :login');
		$req->execute(array("login"=>$login));
		return $req;
	}

	else
	{
		return false;
	}
}
