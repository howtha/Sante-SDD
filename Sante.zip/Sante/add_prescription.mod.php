<?php
require('sql.php');

function add_prescription($name, $taking, $duration, $doctor, $social_security, $bdd)
{
	$req = $bdd->prepare('INSERT INTO prescription(name, taking, duration, doctor, social_security, date_prescription) VALUES(:name, :taking, :duration, :doctor, :social_security, :date_prescription)');
		$req->execute(array("name"=>$name, "taking"=>$taking, "duration"=>$duration, "doctor"=>$doctor, "social_security"=>$social_security, "date_prescription"=>date("Y-m-d")));
		return $req;
}
