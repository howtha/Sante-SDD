<?php
session_start();
require ("add_prescription.mod.php");

if (isset($_POST["submit"]))
{
	if (add_prescription($_POST['name'], $_POST['taking'], $_POST['duration'], $_SESSION['login'], $_POST['social_security'], $bdd))
	{
		?>  
		<script>
			alert('L\'ordonnance a été crée.'); 
			window.location.href = "add_prescription.view.php";
		</script>
		<?php
	}
}