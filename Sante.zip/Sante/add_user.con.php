<?php
require ("add_user.mod.php");
require_once 'googleLib/GoogleAuthenticator.php';
$ga = new GoogleAuthenticator();
$secret = $ga->createSecret();

if (isset($_POST["submit"]))
{
	if (info_exist($_POST['login'], $bdd))
	{
		?>  
		<script>
			alert("Le compte existe déjà."); 
			window.location.href = "add_user.view.php";
		</script>
		<?php
	}

	else if (add_user($_POST['social_security'], $_POST['status'], $_POST['first_name'], $_POST['last_name'], $_POST['birth_date'], $_POST['email'], $_POST['login'], $_POST['password'], $secret, $bdd))
	{
		?>  
		<script>
			alert('Le compte a été crée avec succès.'); 
			window.location.href = "add_user.view.php";
		</script>
		<?php
	}
}
