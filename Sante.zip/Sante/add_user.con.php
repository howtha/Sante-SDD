<?php
require ("add_user.fonc.php");

if(isset($_POST["submit"]))
{
	if (info_exist($_POST['login'], $bdd))
	{
		?>  
		<script>
			alert("Le compte existe déjà."); 
			window.location.href = "admin.php";
		</script>
		<?php
	}

	else if (add_user($_POST['login'], $_POST['password'], $_POST['statut'], $bdd))
	{
		?>  
		<script>
			alert('Le compte a été crée avec succès.'); 
			window.location.href = "admin.php";
		</script>
		<?php
	}

}
?>