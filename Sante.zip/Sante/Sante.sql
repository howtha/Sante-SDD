-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le :  lun. 17 déc. 2018 à 21:46
-- Version du serveur :  10.1.25-MariaDB
-- Version de PHP :  5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `Sante`
--

-- --------------------------------------------------------

--
-- Structure de la table `patients`
--

CREATE TABLE `patients` (
  `social_security` char(15) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `birth_date` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `blood_group` varchar(25) NOT NULL,
  `height` float NOT NULL,
  `weight` float NOT NULL,
  `vaccine` varchar(250) NOT NULL,
  `doctor` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `patients`
--

INSERT INTO `patients` (`social_security`, `first_name`, `last_name`, `birth_date`, `email`, `blood_group`, `height`, `weight`, `vaccine`, `doctor`) VALUES
('123456789123456', 'f', 'd', '2018-12-08', 'a@h.fr', 'B+', 0, 0, '', 'médecin'),
('123456789123457', 'test', 'ok', '1996-03-15', 'x@h.fr', 'O-', 1.56, 74.3, 'niquel', 'médecin'),
('123456789123459', 'x', 'x', '1119-02-11', 'a@h.fr', 'A-', 0, 0, 'A jour', 'médecin'),
('x', 'x', 'x', '2018-12-13', 'x', 'x', 0, 0, 'x', 'test');

-- --------------------------------------------------------

--
-- Structure de la table `prescription`
--

CREATE TABLE `prescription` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `taking` varchar(50) NOT NULL,
  `duration` varchar(50) NOT NULL,
  `doctor` varchar(100) NOT NULL,
  `social_security` char(15) NOT NULL,
  `date_prescription` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `prescription`
--

INSERT INTO `prescription` (`id`, `name`, `taking`, `duration`, `doctor`, `social_security`, `date_prescription`) VALUES
(6, 'Doliprane', '2 fois par jour', '40 jours', 'médecin', '123456789123456', '2018-12-08'),
(7, 'TEST', '2 fois', '2 jours', 'médecin', '123456789123457', '2018-12-08'),
(8, 'Viagra', '2 fois', '30 jours', 'médecin', '123456789123457', '2018-12-14'),
(9, 'Viagra XXL', '40 fois', '30 jours', 'médecin', '123456789123459', '2018-12-14');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `social_security` char(15) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `birth_date` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `google_auth_code` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`social_security`, `first_name`, `last_name`, `birth_date`, `email`, `login`, `password`, `status`, `google_auth_code`) VALUES
('037403740374374', 'x', 'x', '2011-11-11', 'x@x.fr', 'pharmacie', '3b004ac6d8a602681f5ee3587c924855679e21d9', 'Pharmacie', '2RMA7VON7ISAOG3E'),
('123456789123452', 'x', 'x', '2011-11-11', 'x@h.fr', 'médecin', '3b004ac6d8a602681f5ee3587c924855679e21d9', 'Médecin', 'ZKPXKOXSOF4AQ4ZU'),
('123456789123456', 'x', 'x', '2011-11-11', 'x@h.fr', 'administrateur', '3b004ac6d8a602681f5ee3587c924855679e21d9', 'Administrateur', 'HOATHAD37AFLQSGD'),
('123456789123459', 'x', 'x', '2011-11-11', 'x@x.fr', 'patient', '3b004ac6d8a602681f5ee3587c924855679e21d9', 'Patient', '5GHROO23K3MWBJZP');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`social_security`);

--
-- Index pour la table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`id`),
  ADD KEY `social_security` (`social_security`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`social_security`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `prescription`
--
ALTER TABLE `prescription`
  ADD CONSTRAINT `social_security` FOREIGN KEY (`social_security`) REFERENCES `patients` (`social_security`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
