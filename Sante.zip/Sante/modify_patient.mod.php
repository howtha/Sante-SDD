<?php
require('sql.php');

function read_patients($doctor, $bdd)
{
	$req = $bdd->prepare('SELECT * FROM patients WHERE doctor = :doctor');
	$req->execute(array("doctor"=>$doctor));
	
	if ($req->rowCount() >= 1)
	{
		return $req;
	}

	else
	{
		return false;
	}
}

function read_own_patient($social_security, $bdd)
{
	$req = $bdd->prepare('SELECT * FROM patients WHERE social_security = :social_security');
	$req->execute(array("social_security"=>$social_security));
	
	if ($req->rowCount() == 1)
	{
		return $req;
	}

	else
	{
		return false;
	}
}

function modify_patient($social_security, $last_name, $first_name, $birth_date, $email, $blood_group, $height, $weight, $vaccine, $bdd)
{
	$req = $bdd->prepare('UPDATE patients SET social_security = :social_security, last_name = :last_name, first_name = :first_name, birth_date = :birth_date, email = :email, blood_group = :blood_group, height = :height, weight = :weight, vaccine = :vaccine WHERE social_security = :social_security');
	$req->execute(array("social_security"=>$social_security, "last_name"=>$last_name, "first_name"=>$first_name, "birth_date"=>$birth_date, "email"=>$email, "blood_group"=>$blood_group, "height"=>$height, "weight"=>$weight, "vaccine"=>$vaccine));
	return $req;
}

function delete_patient($social_security, $bdd)
{
	$req = $bdd->prepare('DELETE FROM patients WHERE social_security = :social_security');
	$req->execute(array("social_security"=>$social_security));
	return $req;
}