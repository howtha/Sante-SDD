<?php
require("modify_user.mod.php");

if (isset($_POST["submit"]))
{
	modify_user($_POST['id'], $_POST['status'], $_POST['last_name'], $_POST['first_name'], $_POST['birth_date'], $_POST['email'], $_POST['login'], $bdd);
	?>  
		<script>
			alert("Le compte a été modifié."); 
			window.location.href = "modify_user.con.php";
		</script>
	<?php
}
