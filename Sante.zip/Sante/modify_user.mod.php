<?php
require('sql.php');

function read_data($bdd)
{
	$req = $bdd->prepare('SELECT id, first_name, last_name, birth_date, email, login, status FROM users');
	$req->execute();
	
	if ($req->rowCount() >= 1)
	{
		return $req;
	}

	else
	{
		return false;
	}
}

function read_own_data($id, $bdd)
{
	$req = $bdd->prepare('SELECT id, first_name, last_name, birth_date, email, login, status FROM users WHERE id = :id');
	$req->execute(array("id"=>$id));
	
	if ($req->rowCount() == 1)
	{
		return $req;
	}

	else
	{
		return false;
	}
}

function modify_user($id, $status, $last_name, $first_name, $birth_date, $email, $login, $bdd)
{
	$req = $bdd->prepare('UPDATE users SET status = :status, last_name = :last_name, first_name = :first_name, birth_date = :birth_date, email = :email, login = :login WHERE id = :id');
	$req->execute(array("status"=>$status, "last_name"=>$last_name, "first_name"=>$first_name, "birth_date"=>$birth_date, "email"=>$email, "login"=>$login, "id"=>$id));
	return $req;
}

function delete_user($id, $bdd)
{
	$req = $bdd->prepare('DELETE FROM users WHERE id = :id');
	$req->execute(array("id"=>$id));
	return $req;
}
