<?php
session_start();
require('add_user.mod.php');
require_once 'googleLib/GoogleAuthenticator.php';

//Possibilité de faire un compteur (cpt++) et au bout de 3 essais --> bloquer l'adresse IP du visiteur (htaccess) 
if (empty($_SESSION['login']))
{
  ?>  
    <script>
      alert('Accès refusé ! Connectez-vous pour accéder à cet page !'); 
      window.location.href = "index.php";
    </script>
    <?php
}

$req = view_user($_SESSION['login'], $bdd);
while ($data = $req->fetch())
{
	$secret = $data['google_auth_code'];
}

if ($_POST['code'])
{
	$code = $_POST['code'];
	$ga = new GoogleAuthenticator();
	//2 * 30 sec
	$checkresult = $ga->verifyCode($secret, $code, 2);

	if ($checkresult) 
	{
		$_SESSION['ga'] = $code;

		if ($_SESSION['status'] == "Administrateur")
		{
			header('Location: administrateur.php');
		}

		else if ($_SESSION['status'] == "Patient")
		{
			header('Location: patient.php');
		}

		else if ($_SESSION['status'] == "Médecin")
		{
			header('Location: medecin.php');
		}

		else if ($_SESSION['status'] == "Pharmacie")
		{
			header('Location: pharmacie.php');
		}
	} 

	else 
	{
		//On peut mettre un compteur et bloquer l'IP au bout de 3 tentatives
		?>  
		<script>
			alert('Code erroné !'); 
			window.location.href = "index.php";
		</script>
		<?php
	}
}
