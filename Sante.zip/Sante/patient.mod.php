<?php
require('sql.php');

function read_health($social_security, $bdd)
{
	$req = $bdd->prepare('SELECT * FROM patients WHERE social_security = :social_security');
	$req->execute(array("social_security"=>$social_security));
	
	if ($req->rowCount() >= 1)
	{
		return $req;
	}

	else
	{
		return false;
	}
}

function read_own_prescriptions($social_security, $bdd)
{
	$req = $bdd->prepare('SELECT * FROM prescription WHERE social_security = :social_security');
	$req->execute(array("social_security"=>$social_security));
	
	if ($req->rowCount() >= 1)
	{
		return $req;
	}

	else
	{
		return false;
	}
}