 <?php
session_start();
require('add_user.mod.php');
require_once 'googleLib/GoogleAuthenticator.php';

//Possibilité de faire un compteur (cpt++) et au bout de 3 essais --> bloquer l'adresse IP du visiteur (htaccess) 
if (empty($_SESSION['login']))
{
  ?>  
    <script>
      alert('Accès refusé ! Connectez-vous pour accéder à cet page !'); 
      window.location.href = "index.php";
    </script>
    <?php
}

$req = view_user($_SESSION['login'], $bdd);
while ($data = $req->fetch())
{
	$secret = $data['google_auth_code'];
	$social_security = $data['social_security'];
}

$ga = new GoogleAuthenticator();
$qrCodeUrl = $ga->getQRCodeGoogleUrl($social_security, $secret,"94 c'est l'Efrei");
?>


<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Sant-E
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="fonts/icon-font.min.css">
  <link rel="stylesheet" href="assets/css/material-dashboard.css?v=2.0.2"/>
  <link rel="stylesheet" type="text/css" href="assets/css/animate.css">
  <link rel="stylesheet" type="text/css" href="assets/css/select2.min.css">
  <link rel="stylesheet" type="text/css" href="assets/css/util.css">
  <link rel="stylesheet" type="text/css" href="assets/css/main.css">
</head>
<body>
	<div class="container-login100">
		<div style="text-align:center">
			<img class="rounded" src="assets/img/ga.png">
			<span class="login100-form-title p-t-10 p-b-0">
        Authenticator
			</span>
			<span class="login100-form-title p-t-20 p-b-30">
				<img src='<?php echo $qrCodeUrl; ?>' />
			</span>
      <div class="wrap-login100 p-t-0 p-b-0 m-l-105">
        <span class="login100-form-title p-t-0 p-b-0">
          <form method="post" action="interface.php">
            <div class="wrap-input100 validate-input m-b-10">
              <input class="input100" type="text" name="code" placeholder="Authenticator code" autocomplete="off" required>
              <span class="symbol-input100">
                <i class="fa fa-lock"> </i>
              </span>
            </div>
            <div class="container-login100-form-btn p-t-10">
              <button class="login100-form-btn" type="submit" name="submit">
                Valider
              </button>
            </div>
          </form>
        </span>
      </div>
      <div class="text-center w-full p-t-15 p-b-0">
        <h3> <font color="black"> Téléchargez Google Authenticator sur votre smartphone </font> </h3>
        <a href="https://itunes.apple.com/us/app/google-authenticator/id388497605?mt=8" target="_blank"><img class="app" src="assets/img/iphone.png" /></a>
        <a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en" target="_blank"><img class="app" src="assets/img/android.png" /></a>
      </div>
    </div>
  </div>
</body>

</html>


