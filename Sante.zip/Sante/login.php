<?php

require('sql.php');

if (isset($_POST['submit']))
{
	$query = $bdd->prepare("SELECT * FROM users WHERE login = :login");
	$query->bindValue(':login', $_POST['login'], PDO::PARAM_STR);
	$query->execute();
	$data = $query->fetch();
	
	if (($data['password']) == (sha1($_POST['password'])))
	{
		session_start();
		$_SESSION['status'] = $data['status'];
		$_SESSION['last_name'] = $data['last_name'];
		$_SESSION['first_name'] = $data['first_name'];
		$_SESSION['login'] = $data['login'];
		$_SESSION['social_security'] = $data['social_security'];
		header('Location: a2f.php');
	}

	else
	{
		?>  
		<script>
			alert('Identifiant ou mot de passe incorrect.'); 
			window.location.href = "index.php";
		</script>
		<?php
	}

	$requete->CloseCursor();
}

?>