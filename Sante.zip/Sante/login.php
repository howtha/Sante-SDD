<?php

require_once ('sql.php');
session_start();

if (isset($_POST['submit']))
{
	$requete = $bdd->prepare("SELECT * FROM utilisateurs WHERE login = :login");
	$requete->bindValue(':login', $_POST['login'], PDO::PARAM_STR);
	$requete->execute();
	$donnee = $requete->fetch();
	
	if ($donnee['password'] == ($_POST['password']))
	{
		if ($donnee['statut'] == "Administrateur")
		{
			header("Location: admin.php");
		}
	}
	else
	{
		?>  <script>
			alert('Identifiant ou mot de passe incorrect.'); 
			window.location.href = "index.php";
		</script>
		<?php
	}

	$requete->CloseCursor();
}

?>