<?php
if(empty($_SESSION)) 
{ 
  session_start(); 
} 

//Possibilité de faire un compteur (cpt++) et au bout de 3 essais --> bloquer l'adresse IP du visiteur (htaccess) 
if (empty($_SESSION['login']))
{
  ?>  
    <script>
      alert('Accès refusé ! Connectez-vous pour accéder à cet page !'); 
      window.location.href = "index.php";
    </script>
    <?php
}
//Possibilité de faire un compteur (cpt++) et au bout de 3 essais --> supprimer son compte de notre base de donnée et sanctionner
else if ($_SESSION['status'] != "Pharmacie")
{
  session_destroy();
  ?>  
    <script>
      alert('Accès refusé ! Reconnectez-vous !'); 
      window.location.href = "index.php";
    </script>
    <?php
}
?>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="rose" data-background-color="black" data-image="assets/img/sidebar-1.jpg">
      <div class="sidebar-wrapper">
        <div class="user">
          <div class="photo">
            <img src="assets/img/user.png" />
          </div>
          <div class="user-info">
            <a data-toggle="collapse" href="#collapseExample" class="username">
              <span class="username">
                Pharmacie
                <b class="caret"></b>
              </span>
            </a>
            <div class="collapse" id="collapseExample">
              <ul class="nav">
                <li class="nav-item">
                  <a class="nav-link" href="modify_password.php">
                    <span class="sidebar-mini"> MDP </span>
                    <span class="sidebar-normal"> Modifier mon mot de passe </span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <ul class="nav"> 
          <li class="nav-item ">
            <a class="nav-link" href="qr_scan.php">
              <i class="fa fa-qrcode"> </i>
              <p> Scanner ordonnance </p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top " id="navigation-example">
        <div class="container-fluid">
          <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="logout.php">
                  <img src="assets/img/logout.png" alt="Logo" width=35px>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>