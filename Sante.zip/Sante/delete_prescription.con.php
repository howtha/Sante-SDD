<?php
require('delete_prescription.view.php');


if (isset($_GET['id']))
{
  delete_prescription($_GET['id'], $bdd);
  ?>
    <script>
      alert("L'ordonnance a été supprimé."); 
      window.location.href = "delete_prescription.con.php";
    </script>
  <?php
}
