<?php
session_start();
require('fpdf181/fpdf.php');
require('patient.mod.php');

class PDF extends FPDF
{
	function Header()
	{
	    // Police Arial gras 15
	    $this->SetFont('Arial','B',15);
	    // Right
	    $this->Cell(60);
	    // Titre
	    $this->Cell(70,20,'Carnet de sante',1,0,'C');
	    // Saut de ligne
	    $this->Ln(30);
	}

	function Footer()
	{
		// Positionnement à 1,5 cm du bas
	    $this->SetY(-15);
	    // Police Arial italique 8
	    $this->SetFont('Arial','I',8);
	}
}

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Times', 'B', 12);

$req = read_health($_SESSION['social_security'], $bdd);
while ($data = $req->fetch())
{
	$pdf->cell(0, 10, "Securite sociale : " . $data['social_security'], 0, 1);
	$pdf->cell(0, 10, "Nom : " . $data['last_name'], 0, 1);
	$pdf->cell(0, 10, "Prenom : " . $data['first_name'], 0, 1);
	$pdf->cell(0, 10, "Date de naissance : " . date("d/m/Y", strtotime($data['birth_date'])), 0, 1);
	$pdf->cell(0, 10, "Email : " . $data['email'], 0, 1);
	$pdf->cell(0, 10, "Groupe sanguin : " . $data['blood_group'], 0, 1);
	$pdf->cell(0, 10, "Taille : " . $data['height'], 0, 1);
	$pdf->cell(0, 10, "Poids : " . $data['weight'], 0, 1);
	$pdf->cell(0, 10, "Vaccins : " . $data['vaccine'], 0, 1);
	$pdf->cell(0, 10, "Medecin traitant : " . $data['doctor'], 0, 1);
}

$pdf->Output();
